#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/i2c2_master.h"
#include "mcc_generated_files/examples/i2c2_master_example.h"
#include "mcc_generated_files/eusart.h"
#include <xc.h>
#include <stdint.h>
#include <string.h>

uint8_t data;
uint8_t fwd = 0b11101111;
uint8_t off = 0b11101100; // Assuming this pattern turns the motor off

void main(void) {
    SYSTEM_Initialize();
    SPI1_Initialize();
    EUSART_Initialize();
    I2C2_Initialize();
    
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    
    SPI1_Open(SPI1_DEFAULT);

    I2C2_Write1ByteRegister(0x29, 0x80, 0x01);

    uint8_t L1, H1, temp;

    while (1) {
        L1 = I2C2_Read1ByteRegister(0x29, 0x8A);
        H1 = I2C2_Read1ByteRegister(0x29, 0x8B);
        temp = I2C2_Read1ByteRegister(0x4C, 0x00);
        
        uint16_t lightLevel = (uint16_t)(L1 << 8 | H1);
        
        printf("Light Level: %u, Temperature: %u\n\r", lightLevel, temp);

        if (temp > 20 && lightLevel < 1000) {
            CSN_SetLow();
           data = SPI1_ExchangeByte(fwd); // Activate motor
            CSN_SetHigh();
            printf("Motor activated: Temp %u, Light Level %u\n\r", temp, lightLevel);
        } else {
            CSN_SetLow();
            data = SPI1_ExchangeByte(off); // Turn off motor
            CSN_SetHigh();
            printf("Motor deactivated.\n\r");
        }

        __delay_ms(500);
    }
}